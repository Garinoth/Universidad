
int generar_evento(const char *tema, const char *valor);


/* solo para la version avanzada */
int crear_tema(const char *tema);

/* solo para la version avanzada */
int eliminar_tema(const char *tema);
